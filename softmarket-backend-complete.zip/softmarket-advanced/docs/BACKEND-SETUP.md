# SoftMarket backend setup

Supabase Auth + PostgreSQL + RLS is the source of truth. Next.js route handlers validate input, require an authenticated user, and rely on database ownership policies.

## Apply migrations in order

1. `database/schema.sql` (fresh project only)
2. `supabase/migrations/202611070001_studio.sql`
3. `supabase/migrations/202611070002_marketplace_backend.sql`

## Marketplace endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET/POST | `/api/listings` | Search active listings / create draft |
| PATCH/DELETE | `/api/listings/:listingId` | Edit or delete own draft/content |
| POST | `/api/listings/:listingId/publish` | Validate and publish draft |
| GET/POST | `/api/offers` | View relevant offers / submit offer |
| POST | `/api/offers/:offerId/respond` | Seller accepts or declines |
| POST | `/api/offers/:offerId/withdraw` | Buyer withdraws pending offer |
| GET/POST | `/api/messages` | Read/send listing messages |
| GET | `/api/dashboard` | Seller and buyer dashboard data |
| GET/POST/DELETE | `/api/watchlist` | Manage saved listings |
| GET/PATCH | `/api/notifications` | Read and mark notifications |

## Environment variables

Copy `.env.example` to `.env.local`. Set Supabase URL and anon/publishable key, OpenAI key, and GitHub OAuth credentials as required. `SUPABASE_SERVICE_ROLE_KEY` and `GITHUB_TOKEN_ENCRYPTION_KEY` are server-only secrets; never prefix them with `NEXT_PUBLIC_` or commit them to GitHub.

Generate the 32-byte GitHub token encryption key with `openssl rand -hex 32`.

## Security notes

- Users cannot update their profile role, listing status, offer amount, buyer ID, or offer listing ID via ordinary table updates.
- Listing publishing and offer decisions are atomic Postgres functions.
- GitHub OAuth tokens are encrypted and written only through server-side admin access.
- AI endpoints consume a per-user daily quota (default 50 requests).
- Agent currently produces a saved plan for human review; it does not run generated code.
- Add external rate limiting, CAPTCHA/abuse controls, payment-provider webhooks, seller verification, audit monitoring, and a security review before public launch.

## Run locally

```bash
npm install
npm run typecheck
npm run dev
```
