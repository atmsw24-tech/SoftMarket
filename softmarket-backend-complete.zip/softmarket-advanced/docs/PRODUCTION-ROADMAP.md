# SoftMarket production roadmap

## Phase 1 — secure core
- [x] Authenticated Studio project APIs
- [x] Private project files under RLS
- [x] AI chat endpoint with server-only provider key
- [x] Agent planning with persisted review status
- [x] GitHub OAuth state and encrypted token storage foundation
- [ ] Patch/diff model and explicit apply approvals
- [ ] Per-user request quotas and rate limiting
- [ ] CI typecheck, lint, unit and integration tests

## Phase 2 — Replit-like execution
- [ ] Provision isolated ephemeral container or microVM per workspace
- [ ] Workspace file sync and Git operations
- [ ] Terminal API through isolated runner only
- [ ] Preview URL proxy with origin isolation and short-lived signed tokens
- [ ] Build logs, runtime logs, stop/restart and teardown
- [ ] CPU, memory, disk, wall-clock and egress limits
- [ ] Secrets manager; redact secrets from prompts and logs

## Phase 3 — marketplace operations
- [ ] Listing moderation and abuse reports
- [ ] Seller verification and proof-of-ownership workflow
- [ ] Listing analytics with evidence provenance
- [ ] Buyer/seller messaging and notifications
- [ ] Offer accept/reject/counter flow with immutable audit trail
- [ ] Payment provider selection for supported jurisdictions
- [ ] Verified webhooks, refunds, disputes and payout reconciliation

## Phase 4 — scale and trust
- [ ] Search indexing and ranking
- [ ] Backups, point-in-time recovery and restore drills
- [ ] Error tracking, tracing, uptime and cost dashboards
- [ ] Security review and penetration test
- [ ] Terms, privacy, acceptable use and seller/buyer agreements
