import { z } from "zod";

export const projectCreateSchema = z.object({
  name: z.string().trim().min(2).max(80),
  description: z.string().trim().max(500).default(""),
  framework: z.enum(["nextjs", "react", "html"]).default("nextjs"),
});

export const chatSchema = z.object({
  projectId: z.string().uuid(),
  message: z.string().trim().min(1).max(12000),
  history: z.array(z.object({
    role: z.enum(["user", "assistant"]),
    content: z.string().max(12000),
  })).max(30).default([]),
});

export const agentSchema = z.object({
  projectId: z.string().uuid(),
  goal: z.string().trim().min(5).max(6000),
});

export const fileSchema = z.object({
  projectId: z.string().uuid(),
  path: z.string().min(1).max(240).regex(/^[a-zA-Z0-9_./-]+$/),
  content: z.string().max(250000),
});
