export type Listing = {
  id: string;
  seller_id: string;
  title: string;
  slug: string;
  category: string;
  description: string;
  asking_price: number;
  monthly_revenue: number;
  monthly_profit: number;
  business_model: string;
  status: "draft" | "active" | "under_offer" | "sold" | "rejected";
  created_at: string;
};