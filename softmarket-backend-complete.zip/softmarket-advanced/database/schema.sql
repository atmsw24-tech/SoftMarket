-- SoftMarket initial schema for Supabase PostgreSQL.
-- Run this in Supabase Dashboard > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  avatar_url text,
  role text not null default 'user' check (role in ('user','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 2 and 100),
  slug text not null unique,
  category text not null check (category in ('SaaS','AI Tools','E-commerce','Developer Tools','Mobile Apps','Websites')),
  description text not null check (char_length(description) between 30 and 5000),
  asking_price numeric(12,2) not null check (asking_price > 0),
  monthly_revenue numeric(12,2) not null default 0 check (monthly_revenue >= 0),
  monthly_profit numeric(12,2) not null default 0 check (monthly_profit >= 0),
  business_model text not null default 'Subscription',
  status text not null default 'active' check (status in ('draft','active','under_offer','sold','rejected')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.offers (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.listings(id) on delete cascade,
  buyer_id uuid not null references public.profiles(id) on delete cascade,
  amount numeric(12,2) not null check (amount > 0),
  message text,
  status text not null default 'pending' check (status in ('pending','accepted','declined','withdrawn')),
  created_at timestamptz not null default now()
);

create index if not exists listings_status_created_idx on public.listings(status, created_at desc);
create index if not exists listings_category_idx on public.listings(category);
create index if not exists offers_listing_idx on public.offers(listing_id, created_at desc);

-- Automatically create a profile whenever a user signs up.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = ''
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'full_name', ''));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.listings enable row level security;
alter table public.offers enable row level security;

-- Public profiles expose only fields in the profiles table; avoid storing private data here.
create policy "Profiles are viewable by everyone" on public.profiles
for select using (true);
create policy "Users can update own profile" on public.profiles
for update using (auth.uid() = id) with check (auth.uid() = id);

create policy "Active listings are public" on public.listings
for select using (status = 'active' or seller_id = auth.uid());
create policy "Authenticated users can create own listings" on public.listings
for insert to authenticated with check (seller_id = auth.uid());
create policy "Sellers can update own listings" on public.listings
for update to authenticated using (seller_id = auth.uid()) with check (seller_id = auth.uid());
create policy "Sellers can delete own listings" on public.listings
for delete to authenticated using (seller_id = auth.uid());

-- Buyers can see their own offers; sellers can see offers on their listings.
create policy "Buyer and seller can view relevant offers" on public.offers
for select to authenticated using (
  buyer_id = auth.uid() or exists (
    select 1 from public.listings l where l.id = listing_id and l.seller_id = auth.uid()
  )
);
create policy "Buyers can create offers on active listings" on public.offers
for insert to authenticated with check (
  buyer_id = auth.uid() and exists (
    select 1 from public.listings l where l.id = listing_id and l.status = 'active' and l.seller_id <> auth.uid()
  )
);
create policy "Sellers can update offer status" on public.offers
for update to authenticated using (
  exists (select 1 from public.listings l where l.id = listing_id and l.seller_id = auth.uid())
) with check (
  exists (select 1 from public.listings l where l.id = listing_id and l.seller_id = auth.uid())
);

-- NOTE: This starter intentionally does not implement payment/escrow handling.
-- Do not collect card data directly. Add a vetted payment provider and server-side
-- webhook verification before enabling real transactions.