import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import StudioWorkspace from "./workspace";

export default async function StudioPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  const { data: projects } = await supabase.from("studio_projects")
    .select("id,name,description,framework,status,updated_at").order("updated_at", { ascending: false });
  return (
    <main className="min-h-screen bg-[#090d18] text-white">
      <header className="flex items-center justify-between border-b border-white/10 px-6 py-4">
        <Link href="/" className="text-xl font-bold">SoftMarket <span className="text-cyan-400">Studio</span></Link>
        <nav className="flex gap-5 text-sm text-slate-300"><Link href="/marketplace">Marketplace</Link><Link href="/dashboard">Seller dashboard</Link></nav>
      </header>
      <StudioWorkspace initialProjects={projects || []} />
    </main>
  );
}
