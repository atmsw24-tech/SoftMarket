"use client";
import { useEffect, useMemo, useState } from "react";
import { Bot, Code2, FolderPlus, Github, Play, Send, Sparkles, Terminal, WandSparkles } from "lucide-react";

type Project = { id: string; name: string; description: string | null; framework: string; status: string; updated_at: string };
type FileItem = { id: string; path: string; content: string; updated_at: string };

export default function StudioWorkspace({ initialProjects }: { initialProjects: Project[] }) {
  const [projects, setProjects] = useState(initialProjects);
  const [projectId, setProjectId] = useState(initialProjects[0]?.id || "");
  const [files, setFiles] = useState<FileItem[]>([]);
  const [activePath, setActivePath] = useState("");
  const [code, setCode] = useState("");
  const [message, setMessage] = useState("");
  const [goal, setGoal] = useState("");
  const [chat, setChat] = useState<{role:string;content:string}[]>([]);
  const [reply, setReply] = useState("");
  const [plan, setPlan] = useState("");
  const [busy, setBusy] = useState(false);
  const [mode, setMode] = useState<"chat"|"agent">("chat");
  const activeProject = projects.find(p => p.id === projectId);
  const tree = useMemo(() => files.map(f => f.path), [files]);

  async function refreshFiles(id = projectId) {
    if (!id) return;
    const r = await fetch(`/api/projects/${id}/files`);
    const d = await r.json();
    if (r.ok) {
      setFiles(d.files);
      if (d.files[0]) { setActivePath(d.files[0].path); setCode(d.files[0].content); }
      else { setActivePath(""); setCode(""); }
    }
  }
  useEffect(() => { if (projectId) void refreshFiles(projectId); }, [projectId]);

  async function createProject() {
    const name = prompt("Project name?");
    if (!name) return;
    setBusy(true);
    const r = await fetch("/api/projects", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({name,framework:"nextjs"}) });
    const d = await r.json();
    if (r.ok) { setProjects(p => [d.project,...p]); setProjectId(d.project.id); setFiles([]); setActivePath(""); setCode(""); setChat([]); }
    else alert(d.error || "Could not create project");
    setBusy(false);
  }
  async function saveFile() {
    if (!projectId || !activePath) return;
    setBusy(true);
    const r = await fetch(`/api/projects/${projectId}/files`, { method:"PUT", headers:{"Content-Type":"application/json"}, body:JSON.stringify({path:activePath,content:code}) });
    const d = await r.json();
    if (!r.ok) alert(d.error || "Save failed"); else await refreshFiles();
    setBusy(false);
  }
  async function sendChat() {
    if (!message.trim() || !projectId) return;
    const current = [...chat, {role:"user",content:message}];
    setChat(current); setMessage(""); setBusy(true); setReply("");
    const r = await fetch("/api/ai/chat", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({projectId,message:current[current.length-1].content,history:chat.slice(-12)})});
    const d = await r.json();
    const answer = r.ok ? d.message : `Error: ${d.error || "AI request failed"}`;
    setChat([...current,{role:"assistant",content:answer}]); setBusy(false);
  }
  async function runAgent() {
    if (!goal.trim() || !projectId) return;
    setBusy(true); setPlan("");
    const r = await fetch("/api/ai/agent",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({projectId,goal})});
    const d = await r.json();
    setPlan(r.ok ? d.plan : `Error: ${d.error || "Agent request failed"}`);
    setBusy(false);
  }

  return <div className="mx-auto max-w-[1600px] p-5">
    <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
      <div><p className="text-xs uppercase tracking-[.25em] text-cyan-300">AI development environment</p><h1 className="mt-1 text-3xl font-semibold">Build something real.</h1></div>
      <div className="flex gap-2">
        <button onClick={()=>location.href="/api/github/connect"} className="rounded-lg border border-white/15 px-3 py-2 text-sm"><Github className="mr-2 inline h-4 w-4"/>Connect GitHub</button>
        <button onClick={createProject} disabled={busy} className="rounded-lg bg-cyan-400 px-3 py-2 text-sm font-semibold text-slate-950"><FolderPlus className="mr-2 inline h-4 w-4"/>New project</button>
      </div>
    </div>
    <div className="mb-4 flex items-center gap-3 rounded-xl border border-white/10 bg-white/[.04] p-3">
      <span className="text-sm text-slate-400">Workspace</span>
      <select value={projectId} onChange={e=>{setProjectId(e.target.value);setChat([])}} className="min-w-48 rounded-md bg-slate-900 px-3 py-2 text-sm">{projects.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select>
      <span className="text-xs text-slate-500">{activeProject?.framework || "No project selected"}</span>
      <span className="ml-auto text-xs text-slate-500">Changes are saved to your private Supabase workspace</span>
    </div>
    <div className="grid min-h-[680px] gap-3 xl:grid-cols-[220px_minmax(0,1fr)_390px]">
      <aside className="rounded-xl border border-white/10 bg-[#101728] p-3">
        <div className="mb-3 flex items-center justify-between"><span className="text-xs font-semibold uppercase tracking-wider text-slate-400">Explorer</span><button onClick={()=>refreshFiles()} className="text-xs text-cyan-300">Refresh</button></div>
        <div className="mb-3 text-sm font-medium">{activeProject?.name || "Choose a project"}</div>
        {tree.map(path=><button key={path} onClick={()=>{const f=files.find(x=>x.path===path);if(f){setActivePath(path);setCode(f.content)}}} className={`mb-1 block w-full truncate rounded-md px-2 py-2 text-left text-sm ${activePath===path?"bg-cyan-400/15 text-cyan-200":"text-slate-300 hover:bg-white/5"}`}><Code2 className="mr-2 inline h-4 w-4"/>{path}</button>)}
        {!files.length && <p className="text-xs leading-5 text-slate-500">No files yet. Create a file by entering its path below.</p>}
        <input id="new-path" placeholder="src/app/page.tsx" className="mt-5 w-full rounded-md border border-white/10 bg-slate-950 px-2 py-2 text-xs"/>
        <button onClick={()=>{const el=document.getElementById("new-path") as HTMLInputElement;if(el.value){setActivePath(el.value);setCode("");}}} className="mt-2 w-full rounded-md border border-white/10 py-2 text-xs text-slate-300">Create / open file</button>
      </aside>
      <section className="flex min-w-0 flex-col overflow-hidden rounded-xl border border-white/10 bg-[#101728]">
        <div className="flex items-center justify-between border-b border-white/10 px-4 py-3"><div className="text-sm text-slate-300"><Code2 className="mr-2 inline h-4 w-4 text-cyan-300"/>{activePath || "No file selected"}</div><div className="flex gap-2"><button onClick={saveFile} disabled={busy||!activePath} className="rounded-md bg-cyan-400 px-3 py-1.5 text-xs font-semibold text-slate-950">Save file</button><button onClick={()=>alert("Preview runner is not connected yet. Configure an isolated execution provider before running untrusted project code.")} className="rounded-md border border-white/15 px-3 py-1.5 text-xs"><Play className="mr-1 inline h-3 w-3"/>Preview</button></div></div>
        <textarea value={code} onChange={e=>setCode(e.target.value)} spellCheck={false} placeholder="// Select or create a file to start editing" className="min-h-[590px] flex-1 resize-none bg-[#0b1120] p-5 font-mono text-[13px] leading-6 text-slate-200 outline-none"/>
        <div className="border-t border-white/10 px-4 py-2 text-xs text-slate-500"><Terminal className="mr-2 inline h-3 w-3"/>Editor foundation · isolated runtime integration required for code execution</div>
      </section>
      <aside className="flex min-h-[680px] flex-col rounded-xl border border-white/10 bg-[#101728]">
        <div className="flex border-b border-white/10 p-2"><button onClick={()=>setMode("chat")} className={`flex-1 rounded-lg py-2 text-sm ${mode==="chat"?"bg-cyan-400/15 text-cyan-200":"text-slate-400"}`}><Bot className="mr-2 inline h-4 w-4"/>AI Chat</button><button onClick={()=>setMode("agent")} className={`flex-1 rounded-lg py-2 text-sm ${mode==="agent"?"bg-cyan-400/15 text-cyan-200":"text-slate-400"}`}><WandSparkles className="mr-2 inline h-4 w-4"/>Agent</button></div>
        {mode==="chat" ? <>
          <div className="flex-1 space-y-3 overflow-y-auto p-3">{!chat.length&&<div className="rounded-lg bg-cyan-400/10 p-3 text-sm text-slate-300"><Sparkles className="mb-2 h-5 w-5 text-cyan-300"/>Ask about architecture, debugging, code, tests, or product decisions. The assistant receives the project file context.</div>}{chat.map((m,i)=><div key={i} className={`rounded-lg p-3 text-sm leading-6 ${m.role==="user"?"ml-5 bg-slate-700/60":"mr-3 bg-slate-900"}`}><div className="mb-1 text-[10px] uppercase tracking-wider text-cyan-300">{m.role==="user"?"You":"SoftMarket AI"}</div><pre className="whitespace-pre-wrap font-sans">{m.content}</pre></div>)}{busy&&<p className="text-xs text-cyan-300">Thinking…</p>}</div>
          <div className="border-t border-white/10 p-3"><textarea value={message} onChange={e=>setMessage(e.target.value)} onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();sendChat()}}} placeholder="Ask the AI to help build…" className="w-full resize-none rounded-lg border border-white/10 bg-slate-950 p-3 text-sm outline-none" rows={3}/><button disabled={busy||!projectId} onClick={sendChat} className="mt-2 w-full rounded-lg bg-cyan-400 py-2 text-sm font-semibold text-slate-950"><Send className="mr-2 inline h-4 w-4"/>Send</button></div>
        </> : <>
          <div className="flex-1 overflow-y-auto p-4"><div className="mb-3 rounded-lg bg-violet-400/10 p-3 text-sm text-slate-300"><WandSparkles className="mb-2 h-5 w-5 text-violet-300"/>Describe an outcome. The agent will create a step-by-step plan for review before any changes are made.</div><textarea value={goal} onChange={e=>setGoal(e.target.value)} placeholder="Build a subscription billing page with pricing tiers, responsive layout, and tests…" rows={5} className="w-full rounded-lg border border-white/10 bg-slate-950 p-3 text-sm outline-none"/><button disabled={busy||!projectId} onClick={runAgent} className="mt-3 w-full rounded-lg bg-violet-400 py-2 text-sm font-semibold text-slate-950">Create agent plan</button>{plan&&<div className="mt-4 whitespace-pre-wrap rounded-lg bg-slate-950 p-3 text-sm leading-6 text-slate-300">{plan}</div>}</div>
        </>}
      </aside>
    </div>
  </div>;
}
