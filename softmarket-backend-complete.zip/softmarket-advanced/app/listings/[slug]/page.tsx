import { createClient } from "@/lib/supabase/client";
import ListingDetail from "./ui";

export default async function ListingPage({params}:{params:Promise<{slug:string}>}) {
  const {slug}=await params;
  return <ListingDetail slug={slug}/>;
}