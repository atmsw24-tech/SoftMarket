"use client";
import { useEffect, useState } from "react";
import { Search } from "lucide-react";
import ListingCard from "@/components/ListingCard";
import { createClient } from "@/lib/supabase/client";
import type { Listing } from "@/lib/types";

const categories = ["All", "SaaS", "AI Tools", "E-commerce", "Developer Tools", "Mobile Apps", "Websites"];

export default function Marketplace() {
  const [listings,setListings] = useState<Listing[]>([]);
  const [loading,setLoading] = useState(true);
  const [search,setSearch] = useState("");
  const [category,setCategory] = useState("All");
  const [sort,setSort] = useState("created_at");
  const [error,setError] = useState("");
  useEffect(() => {
    const load = async () => {
      try {
        const supabase = createClient();
        let request = supabase.from("listings").select("*").eq("status","active");
        if (category !== "All") request = request.eq("category",category);
        if (search.trim()) request = request.ilike("title",`%${search.trim()}%`);
        const {data,error} = await request.order(sort,{ascending:sort==="asking_price"}).limit(60);
        if(error) throw error;
        setListings((data || []) as Listing[]);
      } catch(e) { setError(e instanceof Error ? e.message : "Could not load listings."); }
      finally { setLoading(false); }
    };
    const timer = setTimeout(load,250);
    return () => clearTimeout(timer);
  },[category,search,sort]);
  return <main className="container py-12">
    <div className="flex flex-wrap justify-between items-end gap-4 mb-7"><div><p className="text-xs uppercase tracking-widest font-bold text-[#5b4bdb]">Explore</p><h1 className="text-3xl font-black mt-2">Software marketplace</h1><p className="muted mt-2 text-sm">Find a product or business worth building on.</p></div><span className="text-sm muted">{listings.length} listings</span></div>
    <div className="panel p-3 grid sm:grid-cols-[1fr_220px_190px] gap-3 mb-6">
      <div className="relative"><Search size={17} className="absolute left-3 top-3.5 muted"/><input className="field pl-10" placeholder="Search listings by title..." value={search} onChange={e=>setSearch(e.target.value)}/></div>
      <select className="field" value={category} onChange={e=>setCategory(e.target.value)}>{categories.map(c=><option key={c}>{c}</option>)}</select>
      <select className="field" value={sort} onChange={e=>setSort(e.target.value)}><option value="created_at">Recently added</option><option value="asking_price">Price: low to high</option><option value="monthly_revenue">Monthly revenue</option></select>
    </div>
    {loading ? <p className="muted py-10">Loading listings...</p> : error ? <div className="panel p-5 text-sm text-red-600">{error}<p className="mt-2 text-xs muted">Check your Supabase environment variables and run database/schema.sql.</p></div> : listings.length ? <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">{listings.map(l=><ListingCard key={l.id} listing={l}/>)}</div> : <div className="panel p-10 text-center"><h2 className="font-bold text-lg">No listings found yet</h2><p className="muted text-sm mt-2">Be the first to list a software business.</p></div>}
  </main>;
}