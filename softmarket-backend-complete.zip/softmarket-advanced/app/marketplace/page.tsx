import { createClient } from "@/lib/supabase/client";
import Marketplace from "./ui";

export default function MarketplacePage() { return <Marketplace />; }