import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";

const input = z.object({
  title: z.string().trim().min(5).max(100),
  category: z.enum(["SaaS", "AI Tools", "E-commerce", "Developer Tools", "Mobile Apps", "Websites"]),
  description: z.string().trim().min(30).max(5000),
  asking_price: z.coerce.number().positive().max(1_000_000_000),
  monthly_revenue: z.coerce.number().min(0).max(1_000_000_000).default(0),
  monthly_profit: z.coerce.number().min(0).max(1_000_000_000).default(0),
  business_model: z.string().trim().min(2).max(60).default("Subscription"),
});
const slugify = (s: string) => s.toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 75);

export async function GET(request: Request) {
  const url = new URL(request.url);
  const q = url.searchParams.get("q")?.trim().slice(0, 80).replace(/[%_,]/g, "");
  const category = url.searchParams.get("category");
  const db = await createClient();
  let query = db.from("listings").select("id,title,slug,category,description,asking_price,monthly_revenue,monthly_profit,business_model,status,created_at,seller_id")
    .eq("status", "active").order("created_at", { ascending: false }).limit(60);
  if (q) query = query.ilike("title", `%${q}%`);
  if (category) query = query.eq("category", category);
  const min = Number(url.searchParams.get("min") || 0), max = Number(url.searchParams.get("max") || 0);
  if (Number.isFinite(min) && min > 0) query = query.gte("asking_price", min);
  if (Number.isFinite(max) && max > 0) query = query.lte("asking_price", max);
  const { data, error } = await query;
  if (error) return NextResponse.json({ error: "Could not load listings." }, { status: 400 });
  return NextResponse.json({ listings: data });
}

export async function POST(request: Request) {
  const { supabase, user } = await requireUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const parsed = input.safeParse(await request.json());
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 422 });
  const slug = `${slugify(parsed.data.title) || "software"}-${crypto.randomUUID().slice(0, 8)}`;
  const { data, error } = await supabase.from("listings").insert({
    ...parsed.data, slug, seller_id: user.id,
  }).select("id,title,slug,status").single();
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ listing: data }, { status: 201 });
}
