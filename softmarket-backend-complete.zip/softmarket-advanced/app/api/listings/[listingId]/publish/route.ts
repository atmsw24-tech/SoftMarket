import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";
export async function POST(_: Request, { params }: { params: Promise<{ listingId: string }> }) {
  const { listingId } = await params;
  const { supabase, user } = await requireUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { data, error } = await supabase.rpc("publish_listing", { p_listing_id: listingId });
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ listing: data });
}
