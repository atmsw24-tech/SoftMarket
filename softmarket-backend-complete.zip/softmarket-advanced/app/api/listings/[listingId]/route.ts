import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
const update = z.object({
  title: z.string().trim().min(5).max(100).optional(),
  category: z.enum(["SaaS", "AI Tools", "E-commerce", "Developer Tools", "Mobile Apps", "Websites"]).optional(),
  description: z.string().trim().min(30).max(5000).optional(),
  asking_price: z.coerce.number().positive().max(1_000_000_000).optional(),
  monthly_revenue: z.coerce.number().min(0).max(1_000_000_000).optional(),
  monthly_profit: z.coerce.number().min(0).max(1_000_000_000).optional(),
  business_model: z.string().trim().min(2).max(60).optional(),
}).strict();
export async function PATCH(request: Request, { params }: { params: Promise<{ listingId: string }> }) {
  const { listingId } = await params;
  const { supabase, user } = await requireUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const parsed = update.safeParse(await request.json());
  if (!parsed.success || Object.keys(parsed.data || {}).length === 0) return NextResponse.json({ error: parsed.success ? "No changes supplied" : parsed.error.flatten() }, { status: 422 });
  const { data, error } = await supabase.from("listings").update(parsed.data).eq("id", listingId).eq("seller_id", user.id).select("id,title,slug,status,updated_at").single();
  if (error || !data) return NextResponse.json({ error: "Listing not found or update not permitted." }, { status: 404 });
  return NextResponse.json({ listing: data });
}
export async function DELETE(_: Request, { params }: { params: Promise<{ listingId: string }> }) {
  const { listingId } = await params;
  const { supabase, user } = await requireUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { data, error } = await supabase.from("listings").delete().eq("id", listingId).eq("seller_id", user.id).eq("status", "draft").select("id").maybeSingle();
  if (error || !data) return NextResponse.json({ error: "Only your own draft listing can be deleted." }, { status: 400 });
  return NextResponse.json({ ok: true });
}
