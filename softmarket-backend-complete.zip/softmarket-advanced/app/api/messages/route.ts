import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
const schema = z.object({ listing_id: z.string().uuid(), recipient_id: z.string().uuid(), content: z.string().trim().min(1).max(4000) });
export async function GET(request: Request) {
  const listingId = new URL(request.url).searchParams.get("listing_id");
  if (!listingId) return NextResponse.json({ error: "listing_id is required" }, { status: 422 });
  const { supabase, user } = await requireUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { data, error } = await supabase.from("listing_messages").select("id,listing_id,sender_id,recipient_id,content,read_at,created_at").eq("listing_id", listingId).order("created_at").limit(200);
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ messages: data });
}
export async function POST(request: Request) {
  const { supabase, user } = await requireUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const parsed = schema.safeParse(await request.json());
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 422 });
  const { data, error } = await supabase.from("listing_messages").insert({ ...parsed.data, sender_id: user.id }).select("id,listing_id,sender_id,recipient_id,content,created_at").single();
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ message: data }, { status: 201 });
}
