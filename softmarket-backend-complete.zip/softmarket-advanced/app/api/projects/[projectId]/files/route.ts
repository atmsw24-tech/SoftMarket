import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";
import { fileSchema } from "@/lib/validation";

export async function GET(_: Request, { params }: { params: Promise<{ projectId: string }> }) {
  const { projectId } = await params;
  const { supabase, user } = await requireUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { data: project } = await supabase.from("studio_projects").select("id").eq("id", projectId).single();
  if (!project) return NextResponse.json({ error: "Project not found" }, { status: 404 });
  const { data, error } = await supabase.from("studio_files").select("id,path,content,updated_at")
    .eq("project_id", projectId).order("path");
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ files: data });
}

export async function PUT(request: Request, { params }: { params: Promise<{ projectId: string }> }) {
  const { projectId } = await params;
  const { supabase, user } = await requireUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const parsed = fileSchema.safeParse({ ...(await request.json()), projectId });
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 422 });
  const { data: project } = await supabase.from("studio_projects").select("id").eq("id", projectId).single();
  if (!project) return NextResponse.json({ error: "Project not found" }, { status: 404 });
  const { data, error } = await supabase.from("studio_files").upsert({
    project_id: projectId, path: parsed.data.path, content: parsed.data.content,
    updated_by: user.id,
  }, { onConflict: "project_id,path" }).select("id,path,updated_at").single();
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ file: data });
}
