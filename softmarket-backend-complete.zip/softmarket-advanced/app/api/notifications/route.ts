import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
const schema=z.object({id:z.string().uuid()});
export async function GET(){const {supabase,user}=await requireUser();if(!user)return NextResponse.json({error:"Unauthorized"},{status:401});const {data,error}=await supabase.from("notifications").select("id,kind,title,body,href,read_at,created_at").order("created_at",{ascending:false}).limit(50);if(error)return NextResponse.json({error:error.message},{status:400});return NextResponse.json({notifications:data});}
export async function PATCH(request:Request){const {supabase,user}=await requireUser();if(!user)return NextResponse.json({error:"Unauthorized"},{status:401});const parsed=schema.safeParse(await request.json());if(!parsed.success)return NextResponse.json({error:parsed.error.flatten()},{status:422});const {data,error}=await supabase.from("notifications").update({read_at:new Date().toISOString()}).eq("id",parsed.data.id).select("id,read_at").single();if(error)return NextResponse.json({error:"Notification not found."},{status:404});return NextResponse.json({notification:data});}
