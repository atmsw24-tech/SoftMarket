import { NextResponse } from "next/server";
import { randomBytes } from "node:crypto";
import { cookies } from "next/headers";
import { requireUser } from "@/lib/auth";

export async function GET() {
  const { user } = await requireUser();
  if (!user) return NextResponse.redirect(new URL("/login", process.env.APP_URL || "http://localhost:3000"));
  if (!process.env.GITHUB_CLIENT_ID || !process.env.GITHUB_CALLBACK_URL) {
    return NextResponse.json({ error: "Configure GITHUB_CLIENT_ID and GITHUB_CALLBACK_URL first." }, { status: 503 });
  }
  const state = randomBytes(24).toString("hex");
  (await cookies()).set("github_oauth_state", state, { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", maxAge: 600, path: "/" });
  const url = new URL("https://github.com/login/oauth/authorize");
  url.searchParams.set("client_id", process.env.GITHUB_CLIENT_ID);
  url.searchParams.set("redirect_uri", process.env.GITHUB_CALLBACK_URL);
  url.searchParams.set("scope", "read:user user:email repo");
  url.searchParams.set("state", state);
  return NextResponse.redirect(url);
}
