import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { requireUser } from "@/lib/auth";
import { encryptSecret } from "@/lib/github/crypto";
import { createAdminClient } from "@/lib/supabase/admin";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  const cookieStore = await cookies();
  const expected = cookieStore.get("github_oauth_state")?.value;
  cookieStore.delete("github_oauth_state");
  if (!code || !state || !expected || state !== expected) {
    return NextResponse.redirect(new URL("/studio?github=invalid_state", process.env.APP_URL || url.origin));
  }
  const { user } = await requireUser();
  if (!user) return NextResponse.redirect(new URL("/login", url.origin));
  try {
    const tokenResponse = await fetch("https://github.com/login/oauth/access_token", {
      method: "POST", headers: { Accept: "application/json", "Content-Type": "application/json" },
      body: JSON.stringify({ client_id: process.env.GITHUB_CLIENT_ID, client_secret: process.env.GITHUB_CLIENT_SECRET, code })
    });
    const tokenData = await tokenResponse.json();
    if (!tokenResponse.ok || !tokenData.access_token) throw new Error("GitHub token exchange failed");
    const encrypted = encryptSecret(tokenData.access_token);
    const admin = createAdminClient();
    const { error } = await admin.from("github_connections").upsert({
      user_id: user.id, encrypted_access_token: encrypted, scopes: tokenData.scope || ""
    }, { onConflict: "user_id" });
    if (error) throw error;
    return NextResponse.redirect(new URL("/studio?github=connected", url.origin));
  } catch {
    return NextResponse.redirect(new URL("/studio?github=error", url.origin));
  }
}
