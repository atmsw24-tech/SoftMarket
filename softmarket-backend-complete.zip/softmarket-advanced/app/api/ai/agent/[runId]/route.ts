import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";

export async function GET(_: Request, { params }: { params: Promise<{ runId: string }> }) {
  const { runId } = await params;
  const { supabase, user } = await requireUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { data, error } = await supabase.from("studio_agent_runs")
    .select("id,project_id,goal,plan,status,created_at,reviewed_at")
    .eq("id", runId).single();
  if (error || !data) return NextResponse.json({ error: "Agent run not found" }, { status: 404 });
  return NextResponse.json({ run: data });
}
