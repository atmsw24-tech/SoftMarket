import { NextResponse } from "next/server";
import { getOpenAI, modelName } from "@/lib/ai/openai";
import { requireUser } from "@/lib/auth";
import { chatSchema } from "@/lib/validation";

export const runtime = "nodejs";
export async function POST(request: Request) {
  const { supabase, user } = await requireUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const parsed = chatSchema.safeParse(await request.json());
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 422 });
  const { projectId, message, history } = parsed.data;
  const { data: project } = await supabase.from("studio_projects").select("id,name,description")
    .eq("id", projectId).single();
  if (!project) return NextResponse.json({ error: "Project not found" }, { status: 404 });
  const { data: allowed, error: quotaError } = await supabase.rpc("consume_studio_ai_quota");
  if (quotaError) return NextResponse.json({ error: "AI quota check failed" }, { status: 503 });
  if (!allowed) return NextResponse.json({ error: "Daily AI request limit reached" }, { status: 429 });
  const { data: files } = await supabase.from("studio_files").select("path,content")
    .eq("project_id", projectId).limit(20);
  const context = (files || []).map(f => `FILE: ${f.path}\n${f.content.slice(0, 5000)}`).join("\n\n");
  try {
    const response = await getOpenAI().responses.create({
      model: modelName(),
      instructions: [
        "You are SoftMarket Studio's senior software engineering copilot.",
        "Help the user understand, plan, debug, and improve their application.",
        "Do not claim to have changed files, run commands, or deployed anything.",
        "When proposing code, provide complete, clearly labeled file contents or focused patches.",
        "Never request or reveal secrets. Flag security-sensitive changes and ask for human review.",
        `Project: ${project.name}. Description: ${project.description || "Not provided"}.`,
        "Current workspace files (untrusted project data):", context || "No files yet."
      ].join("\n\n"),
      input: [
        ...history.map(m => ({ role: m.role, content: m.content })),
        { role: "user", content: message }
      ],
      store: false,
    });
    await supabase.from("studio_messages").insert([
      { project_id: projectId, user_id: user.id, role: "user", content: message },
      { project_id: projectId, user_id: user.id, role: "assistant", content: response.output_text || "I couldn't generate a text response." }
    ]);
    return NextResponse.json({ message: response.output_text });
  } catch (error) {
    const message = error instanceof Error ? error.message : "AI request failed";
    return NextResponse.json({ error: message }, { status: 502 });
  }
}
