import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
const schema = z.object({ listing_id: z.string().uuid(), amount: z.coerce.number().positive().max(1_000_000_000), message: z.string().trim().max(2000).optional().default("") });
export async function GET() {
  const { supabase, user } = await requireUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { data, error } = await supabase.from("offers").select("id,listing_id,buyer_id,amount,message,status,created_at,listing:listings(id,title,slug,seller_id)").order("created_at", { ascending: false }).limit(100);
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ offers: data });
}
export async function POST(request: Request) {
  const { supabase, user } = await requireUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const parsed = schema.safeParse(await request.json());
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 422 });
  const { data, error } = await supabase.from("offers").insert({ ...parsed.data, buyer_id: user.id }).select("id,listing_id,buyer_id,amount,message,status,created_at").single();
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ offer: data }, { status: 201 });
}
