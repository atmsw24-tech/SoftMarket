import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
const schema = z.object({ decision: z.enum(["accepted", "declined"]) });
export async function POST(request: Request, { params }: { params: Promise<{ offerId: string }> }) {
  const { offerId } = await params;
  const { supabase, user } = await requireUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const parsed = schema.safeParse(await request.json());
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 422 });
  const { data, error } = await supabase.rpc("respond_to_offer", { p_offer_id: offerId, p_decision: parsed.data.decision });
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ offer: data });
}
