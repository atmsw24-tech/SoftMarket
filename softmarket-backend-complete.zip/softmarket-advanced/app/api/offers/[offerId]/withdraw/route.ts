import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";
export async function POST(_: Request, { params }: { params: Promise<{ offerId: string }> }) {
  const { offerId } = await params;
  const { supabase, user } = await requireUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { data, error } = await supabase.rpc("withdraw_offer", { p_offer_id: offerId });
  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ offer: data });
}
