import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";
export async function GET() {
  const { supabase, user } = await requireUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const [listings, offers, sent] = await Promise.all([
    supabase.from("listings").select("id,title,slug,status,asking_price,created_at").eq("seller_id", user.id).order("created_at", { ascending: false }),
    supabase.from("offers").select("id,listing_id,amount,status,created_at,listing:listings!inner(title,seller_id)").eq("listing.seller_id", user.id),
    supabase.from("offers").select("id,listing_id,amount,status,created_at,listing:listings(title,slug)").eq("buyer_id", user.id),
  ]);
  if (listings.error || offers.error || sent.error) return NextResponse.json({ error: "Could not load dashboard." }, { status: 400 });
  const rows = listings.data || [];
  return NextResponse.json({ stats: { totalListings: rows.length, activeListings: rows.filter(x => x.status === "active").length, pendingOffers: (offers.data || []).filter(x => x.status === "pending").length }, listings: rows, receivedOffers: offers.data || [], sentOffers: sent.data || [] });
}
