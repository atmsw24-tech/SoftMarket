import Link from "next/link";
import { ArrowUpRight, BarChart3 } from "lucide-react";
import type { Listing } from "@/lib/types";

const currency = (n: number) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(n || 0);

export default function ListingCard({ listing }: { listing: Listing }) {
  return <article className="panel p-5 flex flex-col gap-4">
    <div className="flex justify-between items-start gap-3">
      <div><span className="text-xs font-bold text-[#5b4bdb] bg-[#f0efff] px-2 py-1 rounded-md">{listing.category}</span>
      <h3 className="font-extrabold text-lg mt-3">{listing.title}</h3></div>
      <span className="w-10 h-10 rounded-xl bg-[#f3f4f8] grid place-items-center text-[#5b4bdb]"><BarChart3/></span>
    </div>
    <p className="text-sm muted leading-6 line-clamp-2 min-h-12">{listing.description}</p>
    <div className="grid grid-cols-2 gap-3 border-y border-[#e6e9f0] py-3">
      <div><p className="text-xs muted">Monthly revenue</p><b>{currency(listing.monthly_revenue)}</b></div>
      <div><p className="text-xs muted">Monthly profit</p><b>{currency(listing.monthly_profit)}</b></div>
    </div>
    <div className="flex items-end justify-between gap-3">
      <div><p className="text-xs muted">Asking price</p><p className="text-xl font-extrabold">{currency(listing.asking_price)}</p></div>
      <Link href={`/listings/${listing.slug}`} className="btn btn-primary">View listing <ArrowUpRight size={16}/></Link>
    </div>
  </article>;
}