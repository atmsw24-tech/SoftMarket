-- Run with Supabase CLI db tests after configuring local test users.
-- These assertions are intended as a template for pgTAP-based RLS tests.
begin;
select plan(4);
select has_table('public', 'studio_projects', 'studio projects table exists');
select has_table('public', 'studio_files', 'studio files table exists');
select has_table('public', 'studio_agent_runs', 'agent runs table exists');
select has_table('public', 'github_connections', 'GitHub connection table exists');
select * from finish();
rollback;
