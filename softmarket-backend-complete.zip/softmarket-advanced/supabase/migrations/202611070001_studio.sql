-- SoftMarket Studio extension. Apply after the starter schema.
create extension if not exists pgcrypto;

create table if not exists public.studio_projects (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 2 and 80),
  description text not null default '' check (char_length(description) <= 500),
  framework text not null default 'nextjs' check (framework in ('nextjs','react','html')),
  status text not null default 'active' check (status in ('active','archived')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists studio_projects_owner_updated_idx on public.studio_projects(owner_id, updated_at desc);

create table if not exists public.studio_files (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.studio_projects(id) on delete cascade,
  path text not null check (char_length(path) between 1 and 240),
  content text not null default '' check (char_length(content) <= 250000),
  updated_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(project_id, path)
);
create index if not exists studio_files_project_idx on public.studio_files(project_id);

create table if not exists public.studio_messages (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.studio_projects(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('user','assistant')),
  content text not null check (char_length(content) <= 20000),
  created_at timestamptz not null default now()
);
create index if not exists studio_messages_project_created_idx on public.studio_messages(project_id, created_at);

create table if not exists public.studio_agent_runs (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.studio_projects(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  goal text not null check (char_length(goal) <= 6000),
  plan text not null check (char_length(plan) <= 30000),
  status text not null default 'awaiting_review'
    check (status in ('awaiting_review','approved','rejected','completed','failed')),
  created_at timestamptz not null default now(),
  reviewed_at timestamptz
);
create index if not exists studio_agent_runs_project_idx on public.studio_agent_runs(project_id, created_at desc);

-- Store only authenticated/encrypted GitHub credentials; never expose this table via client grants.
create table if not exists public.studio_ai_usage (
  user_id uuid not null references auth.users(id) on delete cascade,
  usage_date date not null default current_date,
  requests integer not null default 0 check (requests >= 0),
  primary key (user_id, usage_date)
);

create table if not exists public.github_connections (
  user_id uuid primary key references auth.users(id) on delete cascade,
  encrypted_access_token text not null,
  scopes text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.touch_updated_at()
returns trigger language plpgsql set search_path = ''
as $$ begin new.updated_at = now(); return new; end; $$;

drop trigger if exists studio_projects_touch on public.studio_projects;
create trigger studio_projects_touch before update on public.studio_projects
for each row execute function public.touch_updated_at();
drop trigger if exists studio_files_touch on public.studio_files;
create trigger studio_files_touch before update on public.studio_files
for each row execute function public.touch_updated_at();

alter table public.studio_projects enable row level security;
alter table public.studio_files enable row level security;
alter table public.studio_messages enable row level security;
alter table public.studio_agent_runs enable row level security;
alter table public.github_connections enable row level security;
alter table public.studio_ai_usage enable row level security;

drop policy if exists "project owner manages projects" on public.studio_projects;
create policy "project owner manages projects" on public.studio_projects
for all to authenticated using ((select auth.uid()) = owner_id)
with check ((select auth.uid()) = owner_id);

drop policy if exists "project owner manages files" on public.studio_files;
create policy "project owner manages files" on public.studio_files
for all to authenticated using (exists (
  select 1 from public.studio_projects p
  where p.id = project_id and p.owner_id = (select auth.uid())
)) with check (exists (
  select 1 from public.studio_projects p
  where p.id = project_id and p.owner_id = (select auth.uid())
));

drop policy if exists "project owner reads messages" on public.studio_messages;
create policy "project owner reads messages" on public.studio_messages
for select to authenticated using (exists (
  select 1 from public.studio_projects p
  where p.id = project_id and p.owner_id = (select auth.uid())
));
drop policy if exists "project owner creates messages" on public.studio_messages;
create policy "project owner creates messages" on public.studio_messages
for insert to authenticated with check (
  user_id = (select auth.uid()) and exists (
    select 1 from public.studio_projects p
    where p.id = project_id and p.owner_id = (select auth.uid())
  )
);

drop policy if exists "project owner manages agent runs" on public.studio_agent_runs;
create policy "project owner manages agent runs" on public.studio_agent_runs
for all to authenticated using (exists (
  select 1 from public.studio_projects p
  where p.id = project_id and p.owner_id = (select auth.uid())
)) with check (
  user_id = (select auth.uid()) and exists (
    select 1 from public.studio_projects p
    where p.id = project_id and p.owner_id = (select auth.uid())
  )
);

-- Prevent privilege escalation through the starter profile update policy.
revoke update on public.profiles from authenticated;
grant update (full_name, avatar_url) on public.profiles to authenticated;

-- Sellers may change offer status only; buyer_id, listing_id and amount are immutable to clients.
revoke update on public.offers from authenticated;
grant update (status) on public.offers to authenticated;

-- A user may access only their own encrypted GitHub token. The encryption key stays server-side.
drop policy if exists "user manages own github connection" on public.github_connections;
create policy "user manages own github connection" on public.github_connections
for all to authenticated using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);
grant select, insert, update, delete on public.github_connections to authenticated;

-- Atomic per-user AI quota: default 50 requests per UTC database date.
create or replace function public.consume_studio_ai_quota()
returns boolean language plpgsql security definer set search_path = ''
as $$
declare accepted integer;
begin
  if auth.uid() is null then return false; end if;
  insert into public.studio_ai_usage(user_id, usage_date, requests)
  values (auth.uid(), current_date, 1)
  on conflict (user_id, usage_date) do update
    set requests = public.studio_ai_usage.requests + 1
    where public.studio_ai_usage.requests < 50
  returning requests into accepted;
  return accepted is not null;
end;
$$;
revoke all on function public.consume_studio_ai_quota() from public, anon;
grant execute on function public.consume_studio_ai_quota() to authenticated;
revoke all on public.studio_ai_usage from anon, authenticated;

-- GitHub tokens are server-only at the application layer; ciphertext only is stored in this table.
grant select, insert, update, delete on public.studio_projects, public.studio_files,
  public.studio_messages, public.studio_agent_runs to authenticated;
revoke all on public.studio_projects, public.studio_files, public.studio_messages,
  public.studio_agent_runs from anon;

-- The GitHub connection table is accessed only by server-side privileged code.
-- Do not add a client policy or expose a service-role key to the browser.
