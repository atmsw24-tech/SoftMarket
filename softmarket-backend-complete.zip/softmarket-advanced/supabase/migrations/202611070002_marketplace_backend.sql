-- SoftMarket marketplace hardening and workflows.
-- Apply after database/schema.sql and 202611070001_studio.sql.

-- GitHub OAuth token ciphertext is accessible only to server-side service-role code.
drop policy if exists "user manages own github connection" on public.github_connections;
revoke all on public.github_connections from anon, authenticated;

drop policy if exists "Users can update own profile" on public.profiles;
drop policy if exists "Users can update own public profile" on public.profiles;
create policy "Users can update own public profile" on public.profiles
for update to authenticated using ((select auth.uid()) = id)
with check ((select auth.uid()) = id);
revoke update on public.profiles from anon, authenticated;
grant update(full_name, avatar_url) on public.profiles to authenticated;

alter table public.listings alter column status set default 'draft';
drop policy if exists "Sellers can update own listings" on public.listings;
drop policy if exists "Sellers can update own listing content" on public.listings;
create policy "Sellers can update own listing content" on public.listings
for update to authenticated using (seller_id = (select auth.uid()))
with check (seller_id = (select auth.uid()));
revoke update on public.listings from anon, authenticated;
grant update(title, category, description, asking_price, monthly_revenue, monthly_profit, business_model) on public.listings to authenticated;
revoke insert on public.listings from authenticated;
grant insert(seller_id,title,slug,category,description,asking_price,monthly_revenue,monthly_profit,business_model) on public.listings to authenticated;
grant select, delete on public.listings to authenticated;
grant select on public.listings to anon;
drop policy if exists "Authenticated users can create own listings" on public.listings;
create policy "Authenticated users create own draft listings" on public.listings
for insert to authenticated with check (seller_id=(select auth.uid()) and status='draft');
drop policy if exists "Sellers can delete own listings" on public.listings;
create policy "Sellers can delete own draft listings" on public.listings
for delete to authenticated using (seller_id=(select auth.uid()) and status='draft');

drop policy if exists "Sellers can update offer status" on public.offers;
revoke update, delete on public.offers from anon, authenticated;
revoke insert on public.offers from authenticated;
grant insert(listing_id,buyer_id,amount,message) on public.offers to authenticated;
grant select on public.offers to anon;
drop policy if exists "Buyer and seller can view relevant offers" on public.offers;
create policy "Buyer and seller can view relevant offers" on public.offers
for select to authenticated using (
  buyer_id = (select auth.uid()) or exists (
    select 1 from public.listings l where l.id = listing_id and l.seller_id = (select auth.uid())
  )
);
drop policy if exists "Buyers can create offers on active listings" on public.offers;
create policy "Buyers can create offers on active listings" on public.offers
for insert to authenticated with check (
  buyer_id = (select auth.uid()) and exists (
    select 1 from public.listings l where l.id = listing_id and l.status = 'active' and l.seller_id <> (select auth.uid())
  )
);

create table if not exists public.listing_messages (
  id uuid primary key default gen_random_uuid(), listing_id uuid not null references public.listings(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade, recipient_id uuid not null references auth.users(id) on delete cascade,
  content text not null check (char_length(content) between 1 and 4000), read_at timestamptz,
  created_at timestamptz not null default now(), check (sender_id <> recipient_id)
);
create index if not exists listing_messages_thread_idx on public.listing_messages(listing_id, created_at);

create table if not exists public.listing_conversations (
  listing_id uuid not null references public.listings(id) on delete cascade,
  buyer_id uuid not null references auth.users(id) on delete cascade,
  seller_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(listing_id,buyer_id),
  check (buyer_id <> seller_id)
);
alter table public.listing_conversations enable row level security;
create policy "Conversation participants view thread" on public.listing_conversations
for select to authenticated using (buyer_id=(select auth.uid()) or seller_id=(select auth.uid()));
grant select on public.listing_conversations to authenticated;

alter table public.listing_messages enable row level security;
create policy "Conversation participants read messages" on public.listing_messages
for select to authenticated using (sender_id = (select auth.uid()) or recipient_id = (select auth.uid()));
create policy "Listing participants send messages" on public.listing_messages
for insert to authenticated with check (
  sender_id = (select auth.uid()) and exists (
    select 1 from public.listings l where l.id = listing_id and l.status in ('active','under_offer')
      and ((l.seller_id = recipient_id and sender_id <> l.seller_id)
        or (l.seller_id = sender_id and exists (select 1 from public.listing_conversations c where c.listing_id=l.id and c.buyer_id=recipient_id and c.seller_id=sender_id)))
  )
);
grant select, insert on public.listing_messages to authenticated;
revoke insert on public.listing_messages from authenticated;
grant insert(listing_id,sender_id,recipient_id,content) on public.listing_messages to authenticated;

create or replace function public.after_listing_message()
returns trigger language plpgsql security definer set search_path = '' as $$
declare v_seller uuid; v_title text; v_buyer uuid;
begin
  select seller_id,title into v_seller,v_title from public.listings where id=new.listing_id;
  v_buyer := case when new.sender_id=v_seller then new.recipient_id else new.sender_id end;
  insert into public.listing_conversations(listing_id,buyer_id,seller_id)
    values(new.listing_id,v_buyer,v_seller) on conflict(listing_id,buyer_id) do nothing;
  insert into public.notifications(user_id,kind,title,body,href)
    values(new.recipient_id,'message_received','New marketplace message','You received a message about '||v_title,'/dashboard');
  return new;
end; $$;
drop trigger if exists on_listing_message_created on public.listing_messages;
create trigger on_listing_message_created after insert on public.listing_messages
for each row execute function public.after_listing_message();
revoke all on function public.after_listing_message() from public;

create table if not exists public.watchlist (
  user_id uuid not null references auth.users(id) on delete cascade,
  listing_id uuid not null references public.listings(id) on delete cascade,
  created_at timestamptz not null default now(), primary key(user_id, listing_id)
);
alter table public.watchlist enable row level security;
create policy "Users manage own watchlist" on public.watchlist
for all to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
grant select, insert, delete on public.watchlist to authenticated;

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null check (kind in ('offer_received','offer_accepted','offer_declined','message_received','listing_approved','listing_rejected')),
  title text not null check (char_length(title) <= 160), body text not null default '' check (char_length(body) <= 500),
  href text, read_at timestamptz, created_at timestamptz not null default now()
);
create index if not exists notifications_user_created_idx on public.notifications(user_id, created_at desc);
alter table public.notifications enable row level security;
create policy "Users read own notifications" on public.notifications for select to authenticated using (user_id = (select auth.uid()));
create policy "Users mark own notifications read" on public.notifications for update to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
revoke update on public.notifications from authenticated;
grant update(read_at) on public.notifications to authenticated;
grant select on public.notifications to authenticated;

create table if not exists public.audit_events (
  id bigint generated always as identity primary key, actor_id uuid references auth.users(id) on delete set null,
  entity_type text not null, entity_id text not null, action text not null,
  metadata jsonb not null default '{}'::jsonb, created_at timestamptz not null default now()
);
alter table public.audit_events enable row level security;
revoke all on public.audit_events from anon, authenticated;

create or replace function public.publish_listing(p_listing_id uuid)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_listing public.listings;
begin
  select * into v_listing from public.listings where id=p_listing_id and seller_id=auth.uid() for update;
  if not found then raise exception 'Listing not found'; end if;
  if v_listing.status not in ('draft','rejected') then raise exception 'Listing cannot be published from its current status'; end if;
  if char_length(v_listing.description)<100 then raise exception 'Please provide at least 100 characters of description'; end if;
  update public.listings set status='active',updated_at=now() where id=p_listing_id returning * into v_listing;
  insert into public.audit_events(actor_id,entity_type,entity_id,action) values(auth.uid(),'listing',p_listing_id::text,'published');
  return jsonb_build_object('id',v_listing.id,'status',v_listing.status,'slug',v_listing.slug);
end; $$;

create or replace function public.respond_to_offer(p_offer_id uuid,p_decision text)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_offer public.offers;
begin
  if p_decision not in ('accepted','declined') then raise exception 'Invalid decision'; end if;
  select o.* into v_offer from public.offers o join public.listings l on l.id=o.listing_id
    where o.id=p_offer_id and l.seller_id=auth.uid() for update of o,l;
  if not found then raise exception 'Offer not found'; end if;
  if v_offer.status<>'pending' then raise exception 'Offer is no longer pending'; end if;
  if p_decision='accepted' and not exists(select 1 from public.listings where id=v_offer.listing_id and status='active') then raise exception 'Listing is no longer available'; end if;
  update public.offers set status=p_decision where id=p_offer_id returning * into v_offer;
  if p_decision='accepted' then
    update public.listings set status='under_offer',updated_at=now() where id=v_offer.listing_id and status='active';
    update public.offers set status='declined' where listing_id=v_offer.listing_id and id<>p_offer_id and status='pending';
    insert into public.notifications(user_id,kind,title,body,href) values(v_offer.buyer_id,'offer_accepted','Your offer was accepted','The seller accepted your offer.','/dashboard');
  else
    insert into public.notifications(user_id,kind,title,body,href) values(v_offer.buyer_id,'offer_declined','Your offer was declined','The seller declined your offer.','/dashboard');
  end if;
  insert into public.audit_events(actor_id,entity_type,entity_id,action,metadata) values(auth.uid(),'offer',p_offer_id::text,p_decision,jsonb_build_object('amount',v_offer.amount));
  return jsonb_build_object('id',v_offer.id,'status',v_offer.status,'listing_id',v_offer.listing_id);
end; $$;

create or replace function public.withdraw_offer(p_offer_id uuid)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_offer public.offers;
begin
  update public.offers set status='withdrawn' where id=p_offer_id and buyer_id=auth.uid() and status='pending' returning * into v_offer;
  if not found then raise exception 'Pending offer not found'; end if;
  insert into public.audit_events(actor_id,entity_type,entity_id,action) values(auth.uid(),'offer',p_offer_id::text,'withdrawn');
  return jsonb_build_object('id',v_offer.id,'status',v_offer.status);
end; $$;
revoke all on function public.publish_listing(uuid) from public;
revoke all on function public.respond_to_offer(uuid,text) from public;
revoke all on function public.withdraw_offer(uuid) from public;
grant execute on function public.publish_listing(uuid) to authenticated;
grant execute on function public.respond_to_offer(uuid,text) to authenticated;
grant execute on function public.withdraw_offer(uuid) to authenticated;

create or replace function public.notify_offer_received()
returns trigger language plpgsql security definer set search_path = '' as $$
declare v_seller uuid; v_title text;
begin
  select seller_id,title into v_seller,v_title from public.listings where id=new.listing_id;
  insert into public.notifications(user_id,kind,title,body,href) values(v_seller,'offer_received','New offer received','A buyer submitted an offer on '||v_title,'/dashboard');
  return new;
end; $$;
drop trigger if exists on_offer_created_notify on public.offers;
create trigger on_offer_created_notify after insert on public.offers for each row execute function public.notify_offer_received();
revoke all on function public.notify_offer_received() from public;

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('listing-images','listing-images',true,5242880,array['image/jpeg','image/png','image/webp']) on conflict(id) do nothing;
drop policy if exists "Public can view listing images" on storage.objects;
create policy "Public can view listing images" on storage.objects for select using(bucket_id='listing-images');
drop policy if exists "Authenticated sellers upload listing images" on storage.objects;
create policy "Authenticated sellers upload listing images" on storage.objects for insert to authenticated
with check(bucket_id='listing-images' and (storage.foldername(name))[1]=(select auth.uid())::text);
drop policy if exists "Sellers delete own listing images" on storage.objects;
create policy "Sellers delete own listing images" on storage.objects for delete to authenticated
using(bucket_id='listing-images' and (storage.foldername(name))[1]=(select auth.uid())::text);

-- The agent currently stores plans, not executable actions; clients cannot change run status.
revoke update,delete on public.studio_agent_runs from authenticated;
grant select,insert on public.studio_agent_runs to authenticated;


-- Agent run status is controlled by trusted workflow code, not client inserts/updates.
revoke insert on public.studio_agent_runs from authenticated;
grant insert(project_id,user_id,goal,plan) on public.studio_agent_runs to authenticated;
